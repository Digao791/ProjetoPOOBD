package Builder;

import DataBase.TopeiraDB;
import DataBase.TopeiraWorldDB;
import Entidades.Enemy;
import Main.Game;

import java.util.Random;

public class EnemyGenerator {

        public int xSpawn;
        public int[] targetTime = {60, 70, 80};
        public int time = 0;
        public int aux = 0;

        public Enemy enemy;
        public TopeiraWorldDB twdb;
        public int[] enemyType = {-1,0,1,2,1,0,-1};


        public void tick(){

                time++;
                if(time == targetTime[aux] ) {

                        Random rand = new Random();
                        xSpawn = rand.nextInt(20, 200);
                        int type = rand.nextInt(7);
                        if(Game.entities.size() <= 1)
                                enemyType[3] = 1;
                        enemy = new Enemy(xSpawn, 200, 18, 18, Game.spritesheet.getSprite(112 + enemyType[type]*16,96,16,16));
                        enemy.type = enemyType[type];
                        Game.topeiraDB = new TopeiraDB();
                        if(enemyType[type] == -1){
                                enemy.cor = "Preto";
                                twdb = new TopeiraWorldDB("Preto");

                        }else if(enemyType[type] == 0){
                                enemy.cor = "Marrom";
                                twdb = new TopeiraWorldDB("Marrom");

                        }
                        else if(enemyType[type] == 1){
                                enemy.cor = "Vermelho";
                                twdb = new TopeiraWorldDB("Vermelho");
                        }
                        else if(enemyType[type] == 2){
                                enemy.cor = "Roxo";
                                twdb = new TopeiraWorldDB("Roxo");
                        }


                        Game.topeiraDB.insertEnemy(twdb);
                        Game.enemies.add(enemy);
                        aux = rand.nextInt(2);
                        time = 0;
                }



        }





}
