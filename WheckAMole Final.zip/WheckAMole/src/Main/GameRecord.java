package Main;

import DataBase.PlayerDB;
import DataBase.PlayerWorldDB;
import Entidades.Player;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class GameRecord {

    int aux = 0;

    public int currentOption = 0;
    public int maxOptions = 2;
    public ArrayList<PlayerWorldDB> limit;
    public boolean escape = false, up = false, down = false, delete = false;
    public BufferedImage tp = Game.spritesheet.getSprite(0,126,37,34);
    public BufferedImage ws = Game.spritesheet.getSprite(64,125,47,35);
    public BufferedImage ok = Game.spritesheet.getSprite(0,94,38,30);


    public void tick(){
        if(escape){
            escape = false;
            Game.gameMode = "MENU";
        } if(up)
        {
            up = false;
            currentOption--;
            if(currentOption < 0)
            {
                currentOption = maxOptions;
            }
        }
        if(down)
        {
            down = false;
            currentOption++;
            if(currentOption > maxOptions)
            {
                currentOption = 0;
            }
        }

        if(delete)
        {
            delete = false;
            if(currentOption == 0 && limit.size() > 0) {
                Game.jogador.deletePlayer(limit.get(0).id_Mundo);
                limit.remove(0);
            }
            else if(currentOption == 1 && limit.size() >= 2) {
                Game.jogador.deletePlayer(limit.get(1).id_Mundo);
                limit.remove(1);
            }
            else if(currentOption == 2 && limit.size() >= 3) {
                Game.jogador.deletePlayer(limit.get(2).id_Mundo);
                limit.remove(2);
            }
        }
    }

    public void render(Graphics g){
        g.setColor(Color.black);
        g.fillRect(0, 0, Game.WIDTH*Game.SCALE, Game.HEIGHT*Game.SCALE);
        g.setFont(new Font("arial", Font.BOLD,36));
        g.setColor(Color.WHITE);
        g.drawString("GAME RECORDS", (Game.WIDTH)/2 + 80, 70);
        g.setFont(new Font("arial", Font.BOLD,36));

        g.fillRect(0,200,Game.WIDTH*Game.SCALE, 5);
        if(limit.size() > 0) {
            g.drawString("JOGADOR DO MUNDO " + String.valueOf(limit.get(0).id_Mundo), (Game.WIDTH) / 2 + 30, 250);
            g.drawString("PONTUACAO: " + String.valueOf(limit.get(0).pontuacao), (Game.WIDTH) / 2 + 30, 310);
        }
        g.fillRect(0,360,Game.WIDTH*Game.SCALE, 5);
        if(limit.size() >= 2) {
            g.drawString("JOGADOR DO MUNDO " + String.valueOf(limit.get(1).id_Mundo), (Game.WIDTH) / 2 + 30, 410);
            g.drawString("PONTUACAO: " + String.valueOf(limit.get(1).pontuacao), (Game.WIDTH) / 2 + 30, 470);
        }
        g.fillRect(0,520,Game.WIDTH*Game.SCALE, 5);
        if(limit.size() >= 3) {
            g.drawString("JOGADOR DO MUNDO " + String.valueOf(limit.get(2).id_Mundo), (Game.WIDTH) / 2 + 30, 570);
            g.drawString("PONTUACAO: " + String.valueOf(limit.get(2).pontuacao), (Game.WIDTH) / 2 + 30, 630);
        }

        if(currentOption == 0 && limit.size() > 0)
          g.drawString(">",(Game.WIDTH)/2 , 250);
        else if(currentOption == 1 && limit.size() >= 2)
            g.drawString(">",(Game.WIDTH)/2 , 410);
        else if(currentOption == 2 && limit.size() >= 3)
            g.drawString(">",(Game.WIDTH)/2 , 570);

        g.setFont(new Font("arial", Font.BOLD,20));
        g.drawString("Aperte ESC para sair do Game Records",150, 680);
        g.drawString("Aperte DELETE para deletar dados do Game Records",120, 700);

        g.drawImage(tp,20,150,null);
        g.drawImage(ws,20,190,null);
        g.drawImage(ok,20,230,null);

    }






}
