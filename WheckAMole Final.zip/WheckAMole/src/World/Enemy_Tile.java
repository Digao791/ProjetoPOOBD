package World;

import java.awt.image.BufferedImage;

public class Enemy_Tile extends Tile{
    public Enemy_Tile(int x, int y, BufferedImage sprite) {
        super(x, y, sprite);
    }
}
