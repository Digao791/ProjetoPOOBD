package World;

import Main.Game;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Tile {

    public static BufferedImage floorTile = Game.spritesheet.getSprite(0,16,16,16);
    public static BufferedImage wallTile  = Game.spritesheet.getSprite(48,96,16,16);


    private BufferedImage sprite;
    private int x, y;

    public boolean solid = false;

    public Tile(int x, int y, BufferedImage sprite){
        this.x = x;
        this.y = y;
        this.sprite = sprite;
    }

    public void render(Graphics g){
        g.drawImage(sprite, x , y , null);
    }


}
