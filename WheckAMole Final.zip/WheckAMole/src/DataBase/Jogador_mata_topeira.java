package DataBase;

import Main.Game;

import javax.xml.crypto.Data;
import java.sql.CallableStatement;
import java.sql.SQLException;

public class Jogador_mata_topeira extends Database {

    public boolean updatePlayer(int quantidade, int tipo) throws SQLException {
        connect();
        CallableStatement sql = connection.prepareCall("{call mata_topeiras(?,?)}");
        try{
            sql.setInt(1,quantidade);
            sql.setInt(2,tipo);
            sql.execute();
            check = true;
        }catch (SQLException e){
            System.out.println("Erro de operacao: " + e.getMessage());
            check = false;
        }finally {
            try{
                connection.close();
                sql.close();
            }catch (SQLException e){
                System.out.println("Erro ao fechar conexao " + e.getMessage());
            }
        }
        return check;
    }


}
