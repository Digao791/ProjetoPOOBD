package DataBase;

import Entidades.Enemy;
import Main.Game;

import java.sql.SQLException;

public class TopeiraDB extends Database{


    public boolean insertEnemy(TopeiraWorldDB enemy){
        connect();
        String sql = "INSERT INTO Topeira(cor) VALUES(?)";
        try{
            pst = connection.prepareStatement(sql);
            pst.setString(1, enemy.cor);
            pst.execute();
            System.out.println("Inserido com sucesso enemy");
            check = true;
        } catch (SQLException e) {
            System.out.println("Erro de operacao: " + e.getMessage());
            check = false;
        }
        finally {
            try{
                connection.close();
                pst.close();
            }catch (SQLException e){
                System.out.println("Erro ao fechar a conexao: " + e.getMessage());
            }
        }

        return check;
    }
}
