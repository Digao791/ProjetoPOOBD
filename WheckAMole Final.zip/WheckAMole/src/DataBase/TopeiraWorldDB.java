package DataBase;

public class TopeiraWorldDB {

    public int id;
    public String cor;

    public TopeiraWorldDB(String cor){
        this.cor = cor;
    }
}
