package DataBase;

import Entidades.Player;
import Main.Game;

import java.sql.SQLException;
import java.util.ArrayList;

public class PlayerDB extends Database  {

    public boolean insertPlayer(PlayerWorldDB player){
        connect();
        String sql = "INSERT INTO Jogador(pontuacao) VALUES(?)";
        try{
            pst = connection.prepareStatement(sql);
            pst.setInt(1, player.pontuacao);
            pst.execute();
            check = true;
            System.out.println("Inserido com sucesso");
        } catch (SQLException e) {
            System.out.println("Erro de operacao: " + e.getMessage());
            check = false;
        }
        finally {
            try{
                connection.close();
                pst.close();
            }catch (SQLException e){
                System.out.println("Erro ao fechar a conexao: " + e.getMessage());
            }
        }

        return check;
    }

    public  ArrayList<PlayerWorldDB> researchPlayer(){
        connect();
        ArrayList<PlayerWorldDB> players = new ArrayList<>();
        String sql = "SELECT id_Mundo, pontuacao FROM Jogador ORDER BY pontuacao DESC";
        try{
            statement = connection.createStatement();
            result = statement.executeQuery(sql);

            while(result.next()){
                PlayerWorldDB playerTemp = new PlayerWorldDB(result.getInt("Pontuacao"));
                playerTemp.id_Mundo = result.getInt("id_Mundo");
                players.add(playerTemp);
            }
        } catch (SQLException e) {
            System.out.println("Erro de operacao: " + e.getMessage());
        }finally {
            try{
                connection.close();
                statement.close();
                result.close();
            }catch (SQLException e){
                System.out.println("Erro ao fechar conexao: " + e.getMessage());
            }
        }

        return players;
    }

    public boolean deletePlayer(int id){
        connect();
        String sql = "DELETE FROM Jogador WHERE id_Mundo=?";
        try{
            pst = connection.prepareStatement(sql);
            pst.setInt(1,id);
            pst.execute();
            check = true;
        }catch (SQLException e){
            System.out.println("Erro de operacao: " + e.getMessage());
            check = false;
        }finally {
            try{
                connection.close();
                pst.close();
            }catch (SQLException e){
                System.out.println("Erro ao fechar a conexao: " + e.getMessage());
            }
        }
        return check;
    }

    public boolean updatePlayer(int pontos){
        connect();
        String sql = "UPDATE Jogador SET pontuacao=? WHERE id_Mundo=?";
        try{
            pst = connection.prepareStatement(sql);
            pst.setInt(1, pontos);
            pst.setInt(2, Game.gameRecord.limit.size());
            pst.execute();
            check = true;
        }catch (SQLException e){
            System.out.println("Erro de operacao: " + e.getMessage());
            check = false;
        }finally {
            try{
                connection.close();
                pst.close();
            }catch (SQLException e){
                System.out.println("Erro ao fechar conexao " + e.getMessage());
            }
        }
        return check;
    }






}
