-- Criando o Banco de Dados

CREATE DATABASE whack_a_mole;
USE whack_a_mole;

-- Criando Tabelas

CREATE TABLE Mundo (
	id INT NOT NULL AUTO_INCREMENT ,
    Num INT,
    PRIMARY KEY (id)
);

CREATE TABLE Jogador (
	id_Mundo INT AUTO_INCREMENT,
    pontuacao INT,
    PRIMARY KEY (id_Mundo),
    -- Relacionamento 1 x 1
    CONSTRAINT fk1_Mundo
		FOREIGN KEY (id_Mundo)
        REFERENCES Mundo (id)
        ON UPDATE RESTRICT
        ON DELETE CASCADE
);

CREATE TABLE Topeira (
	id INT NOT NULL AUTO_INCREMENT,
    cor CHAR(10) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE Jogador_mata_Topeira (
	id_Jogador INT NOT NULL,
    id_Topeira INT NOT NULL,
    quantidade INT NOT NULL DEFAULT 0,
	PRIMARY KEY (id_Jogador, id_Topeira),
    -- Relacionamento N x N
    CONSTRAINT fk2_Jogador
		FOREIGN KEY (id_Jogador)
        REFERENCES Jogador (id_Mundo)
        ON UPDATE RESTRICT
        ON DELETE CASCADE,
	CONSTRAINT fk2_Topeira
		FOREIGN KEY (id_Topeira)
        REFERENCES Topeira (id)
        ON UPDATE RESTRICT
        ON DELETE CASCADE
);

-- FUNCTION Auxiliar

DELIMITER $$
	DROP FUNCTION IF EXISTS buscar_ultimo_id_Mundo $$
	CREATE FUNCTION buscar_ultimo_id_Mundo ()
		RETURNS INT
		DETERMINISTIC
	BEGIN
		DECLARE ultimo_id INT;
		SET ultimo_id = (SELECT id FROM Mundo ORDER BY id DESC LIMIT 1);
		RETURN ultimo_id;
	END $$
DELIMITER ;

-- Operação de CREATE

DELIMITER $$
	DROP PROCEDURE IF EXISTS novo_jogo $$
	CREATE PROCEDURE novo_jogo ()
		BEGIN
            DECLARE ultimo_id INT;
			INSERT INTO Mundo (id) VALUES (DEFAULT);
            SET ultimo_id = (SELECT buscar_ultimo_id_Mundo());
            INSERT INTO Jogador (id_Mundo, pontuacao) VALUES (ultimo_id, DEFAULT);
            INSERT INTO Jogador_mata_Topeira (id_Jogador, Id_Topeira) VALUES 
					(ultimo_id, 1), (ultimo_id, 2), (ultimo_id, 3), (ultimo_id, 4);
		END $$
DELIMITER ;

-- Operação de READ

DELIMITER $$
	DROP VIEW IF EXISTS listar_jogadores $$
	CREATE VIEW listar_jogadores AS (
		SELECT id_Mundo AS `ID do Jogador`, pontuacao AS `Pontuação` FROM Jogador
    ) $$
DELIMITER ;

-- Operações de UPDATE

DELIMITER $$
	DROP PROCEDURE IF EXISTS atualiza_pontuacao $$
	CREATE PROCEDURE atualiza_pontuacao (IN nova_pontuacao INT)
		BEGIN
            DECLARE ultimo_id INT;
            SET ultimo_id = (SELECT buscar_ultimo_id_Mundo());
            UPDATE Jogador SET pontuacao = nova_pontuacao WHERE id_Mundo = ultimo_id;
		END $$
DELIMITER ;

DELIMITER $$
	DROP PROCEDURE IF EXISTS mata_topeiras $$
	CREATE PROCEDURE mata_topeiras (IN nova_quantidade INT, IN tipo_Topeira INT)
		BEGIN
			DECLARE ultimo_id INT;
            SET ultimo_id = (SELECT buscar_ultimo_id_Mundo());
            UPDATE Jogador_mata_Topeira SET quantidade = nova_quantidade
				WHERE id_Jogador = ultimo_id AND id_Topeira = tipo_Topeira;
		END $$
DELIMITER ;

-- Operação de DELETE

DELIMITER $$
	DROP PROCEDURE IF EXISTS deleta_jogador $$
	CREATE PROCEDURE deleta_jogador (IN id_Jogador INT)
		BEGIN
            DELETE FROM Mundo WHERE id = id_Jogador;
		END $$
DELIMITER ;

-- Inserindo Possíveis Tipos de Topeira

INSERT INTO Topeira (id, cor) VALUES (1, "marrom"), (2, "vermelha"), (3, "azul"), (4, "preta");

SELECT * FROM Topeira;
SELECT * FROM Jogador;





