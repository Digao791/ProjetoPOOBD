package Entidades;

import java.awt.image.BufferedImage;

public class Grass extends Entity{
    public Grass(int x, int y, int width, int height, BufferedImage sprite) {
        super(x, y, width, height, sprite);
    }
}
