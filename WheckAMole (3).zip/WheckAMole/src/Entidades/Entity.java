package Entidades;

import Main.Game;
import World.Tile;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Comparator;

public class Entity {

    protected int x,y, width, height;


    protected BufferedImage sprite;
    public static BufferedImage grass_tile = Game.spritesheet.getSprite(32,32,16,16);

    public Entity(int x, int y, int width, int height, BufferedImage sprite) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.sprite = sprite;
    }

    public Entity() {
    }

    public void tick(){

    }


    public int getX(){
        return (int)this.x;
    }

    public int getY(){
        return (int)this.y;
    }

    public int getWidth(){
        return (int)this.width;
    }

    public int getHeight(){
        return (int)this.height;
    }

    public void setX(int newX){
        this.x = newX;
    }

    public void setY(int newY){
        this.y = newY;
    }


    public void render(Graphics g){
        g.drawImage(sprite,this.getX(),this.getY(),null);
    }





}
