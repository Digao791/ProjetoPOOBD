package World;

import java.awt.image.BufferedImage;

public class Wall_Tile extends Tile{
    public Wall_Tile(int x, int y, BufferedImage sprite) {
        super(x, y, sprite);
    }
}
