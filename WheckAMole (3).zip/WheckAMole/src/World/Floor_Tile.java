package World;

import java.awt.image.BufferedImage;

public class Floor_Tile extends Tile{
    public Floor_Tile(int x, int y, BufferedImage sprite) {
        super(x, y, sprite);
    }
}
