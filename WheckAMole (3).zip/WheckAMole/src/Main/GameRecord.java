package Main;

import DataBase.PlayerDB;
import DataBase.PlayerWorldDB;
import Entidades.Player;

import java.awt.*;
import java.util.ArrayList;

public class GameRecord {

    int aux = 0;
    ArrayList<PlayerWorldDB> limit;
    public boolean escape = false;

    public void tick(){
        if(escape){
            escape = false;
            Game.gameMode = "MENU";
        }
    }

    public void showRecord(){
        for(PlayerWorldDB p: limit){
            aux++;
            System.out.println("ID MUNDO= " + p.id_Mundo);
            System.out.println("POINTS = " + p.pontuacao);
            //g.drawString(String.valueOf(p.id_Mundo), 140, 120 + 20*aux );
            //g.drawString(String.valueOf(p.pontuacao), 170, 120 + 20*aux );


        }
    }

    public void render(Graphics g){
        g.setColor(Color.black);
        g.fillRect(0, 0, Game.WIDTH*Game.SCALE, Game.HEIGHT*Game.SCALE);
        g.setFont(new Font("arial", Font.BOLD,36));
        g.setColor(Color.WHITE);
        g.drawString("GAME RECORDS ?", (Game.WIDTH)/2 + 80, 70);
        g.setFont(new Font("arial", Font.BOLD,36));

        g.fillRect(0,200,Game.WIDTH*Game.SCALE, 5);
        g.drawString("JOGADOR DO MUNDO " + String.valueOf(limit.get(0).id_Mundo), (Game.WIDTH)/2 + 30, 250);
        g.drawString("PONTUACAO: " + String.valueOf(limit.get(0).pontuacao), (Game.WIDTH)/2 + 30, 310);
        g.fillRect(0,360,Game.WIDTH*Game.SCALE, 5);
        g.drawString("JOGADOR DO MUNDO " + String.valueOf(limit.get(1).id_Mundo), (Game.WIDTH)/2 + 30, 410);
        g.drawString("PONTUACAO: " + String.valueOf(limit.get(1).pontuacao), (Game.WIDTH)/2 + 30, 470);
        g.fillRect(0,520,Game.WIDTH*Game.SCALE, 5);
        g.drawString("JOGADOR DO MUNDO " + String.valueOf(limit.get(2).id_Mundo), (Game.WIDTH)/2 + 30, 570);
        g.drawString("PONTUACAO: " + String.valueOf(limit.get(2).pontuacao), (Game.WIDTH)/2 + 30, 630);

    }






}
