package Main;

import java.awt.*;

public class GameOver {


    public String options[] = {"Novo jogo","Sair do jogo"};
    public int currentOption = 0;
    public int maxOptions = options.length - 1;
    public boolean up = false, down = false, enter = false;


    public void tick(){
        if(up)
        {
            up = false;
            currentOption--;
            if(currentOption < 0)
            {
                currentOption = maxOptions;
            }
        }
        if(down)
        {
            down = false;
            currentOption++;
            if(currentOption > maxOptions)
            {
                currentOption = 0;
            }
        }

        if(enter)
        {
            enter = false;

             if(options[currentOption] == "Novo jogo") {
                Game.world.restart();
            }
            else if(options[currentOption] == "Sair do jogo") {
                System.exit(1);
            }
        }
    }

    public void render(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(new Color(0,0,0,100));
        g2.fillRect(0,0,Game.WIDTH*Game.SCALE,Game.HEIGHT*Game.SCALE);

        g.setColor(Color.red);
        g.setFont(new Font("arial", Font.BOLD,36));
        g.drawString(">GAME OVER<", (Game.WIDTH*Game.SCALE)/2 - 140, (Game.HEIGHT*Game.SCALE)/2 - 200);

        g.setColor(Color.white);
        g.setFont(new Font("arial", Font.BOLD,36));
        g.drawString("Novo jogo", (Game.WIDTH*Game.SCALE)/2 -100, (Game.HEIGHT*Game.SCALE)/2 );
        g.drawString("Sair do jogo", (Game.WIDTH*Game.SCALE)/2 - 110, (Game.HEIGHT*Game.SCALE)/2 +100);

        if(options[currentOption] == "Novo jogo") {
            g.drawString(">", (Game.WIDTH*Game.SCALE)/2 -150, (Game.HEIGHT*Game.SCALE)/2 );
        }

        else if(options[currentOption] == "Sair do jogo") {
            g.drawString(">", (Game.WIDTH*Game.SCALE)/2 - 160, (Game.HEIGHT*Game.SCALE)/2 +100);
        }

    }
}
