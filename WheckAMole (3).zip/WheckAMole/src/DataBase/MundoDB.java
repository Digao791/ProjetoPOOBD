package DataBase;

import java.sql.CallableStatement;
import java.sql.SQLException;

public class MundoDB extends Database {

    public int aux = 0;

    public boolean newGame() {
        connect();
        String sql = "INSERT INTO Mundo(Num) VALUES(?)";
        try {
            pst = connection.prepareStatement(sql);
            pst.setInt(1,aux);
            pst.execute();
            check = true;
            System.out.println("Inserido com sucesso");
        } catch (SQLException e) {
            System.out.println("Erro de operacao: " + e.getMessage());
            check = false;
        } finally {
            try {
                connection.close();
                pst.close();
            } catch (SQLException e) {
                System.out.println("Erro ao fechar a conexao: " + e.getMessage());
            }
        }
        return check;
    }
}

