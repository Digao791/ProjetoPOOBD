package DataBase;

public class PlayerWorldDB implements Comparable<PlayerWorldDB>{

    public int id_Mundo;
    public int pontuacao;

    public PlayerWorldDB(int pontuacao){
        this.pontuacao = pontuacao;
    }

    @Override
    public int compareTo(PlayerWorldDB o) {
        if(this.pontuacao < o.pontuacao){
            return -1;
        }
        else if(this.pontuacao > o.pontuacao){
            return 1;
        }
        else {
            return 0;
        }
    }
}
