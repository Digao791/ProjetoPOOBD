package DataBase;

import java.sql.*;

public abstract class Database {

    protected Connection connection;

    protected Statement statement;
    protected ResultSet result;
    protected PreparedStatement pst;

    private static final String USERNAME = "root";
    private static final String PASSWORD = "Rainbowsix791!";
    private static final String DB_NAME = "whack_a_mole";

    private static final String URL = "jdbc:mysql://localhost:3306/" + DB_NAME;
    public boolean check = false;

    public void connect() {
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Successfully connected to the database! Info: " + connection);
        } catch (SQLException error) {
            System.out.println("NAO CONECTADO");
            System.out.println("Connection Error: " + error.getMessage());
        }
    }
}
