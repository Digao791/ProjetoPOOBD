package Builder;

import Entidades.Enemy;
import Main.Game;

import java.util.Random;

public class EnemyGenerator {

        public int xSpawn;
        public int[] targetTime = {60, 70, 80};
        public int time = 0;
        public int aux = 0;

        public Enemy enemy;
        public int[] enemyType = {-1,0,1,2,1,0,-1};


        public void tick(){

                time++;
                if(time == targetTime[aux] ) {

                        Random rand = new Random();
                        xSpawn = rand.nextInt(20, 200);
                        int type = rand.nextInt(7);
                        if(Game.entities.size() <= 1)
                                enemyType[3] = 1;
                        enemy = new Enemy(xSpawn, 200, 18, 18, Game.spritesheet.getSprite(112 + enemyType[type]*16,96,16,16));
                        enemy.type = enemyType[type];
                        if(enemyType[type] == -1){
                                enemy.cor = "Preto";
                        }else if(enemyType[type] == 0){
                                enemy.cor = "Branco";
                        }
                        else if(enemyType[type] == 1){
                                enemy.cor = "Vermelho";
                        }
                        else if(enemyType[type] == 2){
                                enemy.cor = "Roxo";
                        }

                        Game.enemies.add(enemy);
                        aux = rand.nextInt(2);
                        time = 0;
                }



        }





}
