package Main;

import java.awt.*;

public class UI {

    public int ammo = 100;
    public int inimigosEliminados =  0;


    public void tick(){

    }

    public void render(Graphics g){
        g.setFont(Font.getFont("Arial"));
        g.drawImage(Game.spritesheet.getSprite(32,64,16,16),10,220,null );
        g.drawString(String.valueOf(ammo), 26,235);
        g.drawImage(Game.spritesheet.getSprite(112,96,16,16),55,220,null );
        g.drawString(String.valueOf(inimigosEliminados),73, 235 );
        g.drawImage(Game.spritesheet.getSprite(128,128,16,16),85,220,null );
        g.drawString(String.valueOf(Game.player.vida),102, 235 );
    }



}
