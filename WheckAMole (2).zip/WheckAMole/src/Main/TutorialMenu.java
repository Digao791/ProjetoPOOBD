package Main;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class TutorialMenu {

    public BufferedImage mole1;
    public BufferedImage mole2;
    public BufferedImage mole3;
    public BufferedImage mole4;

    public BufferedImage flower;
    public boolean escape = false;
    public boolean F = false;
    public boolean FlowerStealer = false;

    {
        try {
            mole1 = ImageIO.read(getClass().getResource("/Mole.png"));
            mole2 = ImageIO.read(getClass().getResource("/RedMole.png"));
            mole3 = ImageIO.read(getClass().getResource("/BlackMole.png"));
            mole4 = ImageIO.read(getClass().getResource("/PurpleMole.png"));
            flower = ImageIO.read(getClass().getResource("/flower.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void tick(){
        if(escape){
            escape = false;
            Game.gameMode = "MENU";
        }
        else if(F && !FlowerStealer){
                FlowerStealer = true;
                F = false;
        }
        else if (F && FlowerStealer){
            FlowerStealer = false;
            F = false;
        }

    }

    public void render(Graphics g){
        g.setColor(new Color(235,222,207));
        g.fillRect(0, 0, Game.WIDTH*Game.SCALE, Game.HEIGHT*Game.SCALE);
        g.setFont(new Font("arial", Font.BOLD,36));
        g.setColor(Color.black);
        g.drawString("COMO JOGAR ?", (Game.WIDTH)/2 + 80, 70);
        g.setFont(new Font("arial", Font.BOLD,20));
        g.drawString("Com o seu mouse, aponte e clique ",100, 120);
        g.drawString("nas Toupeiras que aparecerem, mas cuidado !!!",100, 150);

        if(!FlowerStealer) {
            g.drawImage(mole1, 100, 190, null);
            g.drawImage(mole2, 100, 310, null);
            g.drawImage(mole3, 100, 430, null);

            g.drawString("Essa eh uma toupeira comum, não te fara mal", 205, 210);
            g.drawString("mas nunca eh ruim querer pontos ne ?", 205, 230);

            g.drawString("Essa eh uma toupeira explosiva, não deixe a cair ", 205, 330);
            g.drawString("a nao ser que queria perder vida rsrs", 205, 360);

            g.drawString("Essa eh uma toupeira das trevas", 205, 450);
            g.drawString("recomendo não mexer com ela", 205, 480);

            g.drawImage(flower, 100, 550, null);
            g.drawString("Esta com problemas ?, colha uma flor ", 205, 570);
            g.drawString("aperte a tecla 'F' para ganhar 1 ponto de Vida", 205, 600);
        }
        else{
            g.drawImage(mole4, 100, 190, null);
            g.drawImage(mole4, 100, 310, null);
            g.drawImage(mole4, 100, 430, null);

            g.drawString("ESSA TOUPEIRA", 205, 210);


            g.drawString("GOSTA DE ROUBAR ", 205, 330);

            g.drawString("!!! FLORES !!!", 205, 450);

            g.drawImage(flower, 100, 550, null);
            g.drawString("NAO DEIXE-A CAIR ", 205, 570);
            g.drawString("aperte a tecla 'F' para ganhar 1 ponto de Vida", 205, 600);

        }

        g.drawString("Aperte ESC para sair do Tutorial",205, 700);

    }

}
