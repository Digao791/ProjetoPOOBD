package Main;

import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.text.AttributedCharacterIterator;
import java.util.Map;

public class Menu {

    public String options[] = {"Como jogar","Carregar jogo","Sair do jogo"};
    public int currentOption = 0;
    public int maxOptions = options.length - 1;
    public boolean up = false, down = false, enter = false, T = false;


    public void tick(){
        if(up)
        {
            up = false;
            currentOption--;
            if(currentOption < 0)
            {
                currentOption = maxOptions;
            }
        }
        if(down)
        {
            down = false;
            currentOption++;
            if(currentOption > maxOptions)
            {
                currentOption = 0;
            }
        }

        if(enter)
        {
            enter = false;
            if(options[currentOption] == "Carregar jogo") {
                Game.gameMode = "NORMAL";

            }
            else if(options[currentOption] == "Como jogar") {
                Game.gameMode = "TUTORIAL";
            }
            else if(options[currentOption] == "Sair do jogo") {
                System.exit(1);
            }
        }

        if(T){
            T = false;
            Game.gameMode = "GAMERECORD";
        }
    }

    public void render(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(new Color(0,0,0,100));
        g2.fillRect(0,0,Game.WIDTH*Game.SCALE,Game.HEIGHT*Game.SCALE);
        g.setColor(Color.red);
        g.setFont(new Font("arial", Font.BOLD,36));
        g.drawString(">MENU<", (Game.WIDTH*Game.SCALE)/2 - 80, (Game.HEIGHT*Game.SCALE)/2 - 200);

        //OPÇÕES DO MENU
        g.setColor(Color.white);
        g.setFont(new Font("arial", Font.BOLD,36));
        g.drawString("Como jogar", (Game.WIDTH*Game.SCALE)/2 -100, (Game.HEIGHT*Game.SCALE)/2 );
        g.drawString("Carregar jogo", (Game.WIDTH*Game.SCALE)/2 - 130, (Game.HEIGHT*Game.SCALE)/2 +100);
        g.drawString("Sair do jogo", (Game.WIDTH*Game.SCALE)/2 - 110, (Game.HEIGHT*Game.SCALE)/2 +200);

        if(options[currentOption] == "Como jogar") {
            g.drawString(">", (Game.WIDTH*Game.SCALE)/2 -150, (Game.HEIGHT*Game.SCALE)/2 );
        }
        else if(options[currentOption] == "Carregar jogo") {
            g.drawString(">", (Game.WIDTH*Game.SCALE)/2 - 180, (Game.HEIGHT*Game.SCALE)/2 +100);
        }
        else if(options[currentOption] == "Sair do jogo") {
            g.drawString(">", (Game.WIDTH*Game.SCALE)/2 - 160, (Game.HEIGHT*Game.SCALE)/2 +200);
        }
    }



}
