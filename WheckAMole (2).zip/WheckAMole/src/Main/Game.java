package Main;

import Builder.EnemyGenerator;
import DataBase.Database;
import DataBase.MundoDB;
import DataBase.PlayerDB;
import DataBase.TopeiraDB;
import Entidades.Enemy;
import Entidades.Entity;
import Entidades.Grass;
import Entidades.Player;
import Graficos.Spritesheet;
import World.World;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Game extends Canvas implements Runnable, KeyListener, MouseListener, MouseMotionListener {


    public static JFrame frame;
    public static Thread thread;
    public static boolean isRunning = false;
    public static final int WIDTH = 240;
    public static final int HEIGHT = 240;
    public static final int SCALE = 3;

    public static Spritesheet spritesheet;
    private BufferedImage image;
    public static World world;
    public static Player player;

    public static UI ui;
    public static int[] pixels;
    public static List<Entity> entities;
    public static List<Enemy> enemies;
    public static EnemyGenerator enemyGenerator;

    public BufferedImage Back_Ground;
    public BufferedImage Back_Ground2;
    public BufferedImage hand;

    public int backGroundX = 0;
    public int backGroundX2 = -240;
    public int backGroundSPD = 1;
    public static Random rand;

    public static Menu menu;
    public static TutorialMenu tutorial;
    public static GameOver gameOver;

    public static PlayerDB jogador;
    public static MundoDB mundoDB;
    public static TopeiraDB topeiraDB;
    public static Database database;

    GameRecord gameRecord;

    public static String gameMode = "TUTORIAL";
    public Game(){
        rand = new Random();
        setPreferredSize(new Dimension(WIDTH*SCALE, HEIGHT*SCALE));
        addKeyListener(this);
        addMouseListener(this);
        initFrame();
        spritesheet = new Spritesheet("/spritesheet.png");
        menu = new Menu();
        tutorial = new TutorialMenu();
        gameOver = new GameOver();
        gameRecord = new GameRecord();
        player = new Player(0,0,16,16, Game.spritesheet.getSprite(96,128,16,16));
        ui = new UI();
        image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        pixels = ((DataBufferInt)image.getRaster().getDataBuffer()).getData();
        entities = new ArrayList<Entity>();
        entities.add(player);
        world = new World("/mundo.png");
        enemies  = new ArrayList<Enemy>();


         jogador = new PlayerDB();
         mundoDB = new MundoDB();
         topeiraDB = new TopeiraDB();

         mundoDB.newGame();


        try {
            Back_Ground = ImageIO.read(getClass().getResource("/bg.png"));
            Back_Ground2 = ImageIO.read(getClass().getResource("/bg.png"));
            hand = Game.spritesheet.getSprite(80,0,80,81);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        enemyGenerator = new EnemyGenerator();

    }

    public void initFrame(){
        frame = new JFrame("#WheckAMole");
        frame.add(this);
        frame.setResizable(false);
        frame.pack();

        Image imagem = null;

        try {
            imagem = ImageIO.read(getClass().getResource("/icon.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }



        frame.setIconImage(imagem);
        frame.setAlwaysOnTop(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public synchronized void start(){
        thread = new Thread(this);
        isRunning = true;
        thread.start();
    }

    public synchronized void stop(){
        isRunning = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
           e.printStackTrace();
        }
    }



    public static void main(String[] args) {
        Game game = new Game();
        game.start();
    }

    public void tick(){
        if(player.ammo <= 0){
            gameMode = "GAMEOVER";
        }
        if(gameMode.equals("NORMAL")) {
            enemyGenerator.tick();
            ui.tick();
            for (int i = 0; i < entities.size(); i++) {
                Entity e = entities.get(i);
                e.tick();
               
            }
            for (int i = 0; i < enemies.size(); i++) {
                Enemy e = enemies.get(i);
                e.tick();
                if (e.getY() >= 220) {
                    if(e.type == 1) {
                        player.vida--;
                        enemies.remove(e);
                    }
                    else if(e.type == 2){
                        Random randomFlower = new Random();
                        if(entities.size() > 1){
                            int index = randomFlower.nextInt(entities.size());
                            if(entities.get(index) instanceof Grass)
                                entities.remove(index);
                            else{
                                while(!(entities.get(index) instanceof Grass)){
                                    index = randomFlower.nextInt(entities.size());
                                }
                                entities.remove(index);
                            }


                        }
                    }
                    enemies.remove(e);

                }
            }


            backGroundX += backGroundSPD;
            if (backGroundX >= WIDTH) {
                backGroundX = -240;
            }

            backGroundX2 += backGroundSPD;
            if (backGroundX2 >= WIDTH) {
                backGroundX2 = -240;
            }

        }
        else if(gameMode.equals("MENU")){
            menu.tick();
        }
        else if(gameMode.equals("GAMEOVER")){
            gameOver.tick();
        }
        else if(gameMode.equals("TUTORIAL")){
            tutorial.tick();
        }
        else if(gameMode.equals("GAMERECORD")){
            gameRecord.tick();
        }



    }

    public void render(){
        BufferStrategy bs = this.getBufferStrategy();
        if(bs == null){
            this.createBufferStrategy(3);
            return;
        }
        Graphics g = image.getGraphics();
        g.setColor(Color.black);
        g.fillRect(0,0,Game.WIDTH, Game.HEIGHT);

        world.render(g);

        ui.render(g);
        g.drawImage(Back_Ground, backGroundX, 0, null);
        g.drawImage(Back_Ground2, backGroundX2, 0, null);
        for(int i = 0; i < entities.size(); i++){
            Entity e = entities.get(i);
            e.render(g);
        }
        for(int i = 0; i < enemies.size(); i++){
            Enemy e = enemies.get(i);
            e.render(g);
        }
        g.drawImage(hand, WIDTH - 80, HEIGHT - 81, null);

        g.dispose();
        g = bs.getDrawGraphics();
        g.drawImage(image,0, 0, WIDTH*SCALE, HEIGHT*SCALE, null);
        if(gameMode.equals("MENU")){
            menu.render(g);
        }
        else if(gameMode.equals("GAMEOVER")){
            gameOver.render(g);
        }
        else if(gameMode.equals("TUTORIAL")){
            tutorial.render(g);
        }
        else if(gameMode.equals("GAMERECORD")){
            gameRecord.render(g);
        }
        bs.show();

    }


    @Override
    public void run() {
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000/amountOfTicks;
        double delta = 0;
        int frames = 0;
        double timer = System.currentTimeMillis();
        requestFocus();
        while(isRunning) {
            long now = System.nanoTime();
            delta+= (now - lastTime)/ns;
            lastTime = now;
            if(delta >= 1) {
                tick();
                render();
                frames++;
                delta--;
            }
            if(System.currentTimeMillis() - timer >= 1000) {
                System.out.println("FPS: " + frames);
                frames = 0;
                timer += 1000;
            }
        }
        stop();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
            if(e.getKeyCode() == KeyEvent.VK_W){
                menu.up = true;
                gameOver.up = true;
            }
            else if(e.getKeyCode() == KeyEvent.VK_S){
                menu.down = true;
                gameOver.down = true;
            }
            else if(e.getKeyCode() == KeyEvent.VK_P){
                gameMode = "MENU";

            }
            else if(e.getKeyCode() == KeyEvent.VK_ENTER){
                if(gameMode.equals("MENU")) {
                    menu.enter = true;
                }
                else if(gameMode.equals("GAMEOVER")) {
                    gameOver.enter = true;
                }
            }
            else if(e.getKeyCode() == KeyEvent.VK_F){
                if(gameMode.equals("NORMAL"))
                    player.F = true;
            }

            if(gameMode.equals("TUTORIAL")){
                if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
                    tutorial.escape = true;
                }
                else if(e.getKeyCode() == KeyEvent.VK_F){
                    tutorial.F = true;
                }
            }
            else if(gameMode.equals("GAMERECORD")){
                if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
                    gameRecord.escape = true;
                }
            }

            if(gameMode.equals("MENU")){
                if(e.getKeyCode() == KeyEvent.VK_T){
                    menu.T = true;
                }
            }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(e.getButton() == MouseEvent.BUTTON1 && gameMode.equals("NORMAL") && player.ammo >= 1){
            player.mouseCLK = true;
            player.x = e.getX()/3;
            player.y = e.getY()/3;
            player.ammo--;
            ui.ammo--;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getButton() == MouseEvent.BUTTON1){
            player.mouseCLK = false;
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
