package DataBase;

import java.sql.SQLException;

public class MundoDB extends Database{


        public boolean newGame(){
            connect();
            String sql = "CALL novo_jogo()";
            try{
                pst = connection.prepareStatement(sql);
                pst.execute();
                check = true;
            }catch (SQLException e){
                System.out.println("Erro de operacao: " + e.getMessage());
            }finally {
                try{
                    connection.close();
                    pst.close();
                }catch (SQLException e){
                    System.out.println("Erro ao fechar a conexao: " + e.getMessage());
                }
                }
            return check;
            }
        }

