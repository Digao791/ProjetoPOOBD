package DataBase;

import Entidades.Player;

import java.sql.SQLException;
import java.util.ArrayList;

public class PlayerDB extends Database{

    public boolean insertPlayer(Player player){
        connect();
        String sql = "INSERT INTO Jogador(pontuacao) VALUES(?)";
        try{
            pst = connection.prepareStatement(sql);
            pst.setInt(1, player.points);
            pst.execute();
            check = true;
        } catch (SQLException e) {
            System.out.println("Erro de operacao: " + e.getMessage());
            check = false;
        }
        finally {
            try{
                connection.close();
                pst.close();
            }catch (SQLException e){
                System.out.println("Erro ao fechar a conexao: " + e.getMessage());
            }
        }

        return check;
    }

    public  ArrayList<Player> researchPlayer(){
        connect();
        ArrayList<Player> players = new ArrayList<>();
        String sql = "SELECT id_Mundo, pontuacao FROM Jogador";
        try{
            statement = connection.createStatement();
            result = statement.executeQuery(sql);

            while(result.next()){
                Player playerTemp = new Player(result.getInt("Pontuacao"));
                playerTemp.id_Mundo = result.getInt("id");
                players.add(playerTemp);
            }
        } catch (SQLException e) {
            System.out.println("Erro de operacao: " + e.getMessage());
        }finally {
            try{
                connection.close();
                statement.close();
                result.close();
            }catch (SQLException e){
                System.out.println("Erro ao fechar conexao: " + e.getMessage());
            }
        }

        return players;
    }



}
