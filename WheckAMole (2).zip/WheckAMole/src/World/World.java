package World;


import Entidades.Enemy;
import Entidades.Entity;
import Entidades.Grass;
import Entidades.Player;
import Graficos.Spritesheet;
import Main.Game;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

public class World {

    public static Tile[] tiles;
    public static int WIDTH, HEIGHT;
    public static final int TILE_SIZE = 16;

    int grassX;
    int grassY;

    public World(String path){
        try {
            BufferedImage map = ImageIO.read(getClass().getResource(path));
            int[] pixels = new int[map.getWidth() * map.getHeight()];
            WIDTH = map.getWidth();
            HEIGHT = map.getHeight();
            tiles = new Tile[WIDTH*HEIGHT];
            map.getRGB(0,0,WIDTH, HEIGHT, pixels, 0, WIDTH);
            for(int xx = 0; xx < WIDTH; xx++){
                for(int yy = 0; yy < HEIGHT; yy++){
                    int pixelAtual = pixels[xx + (yy * WIDTH)];
                    tiles[xx + (yy * WIDTH)] = new Floor_Tile(xx*16, yy*16, Tile.floorTile);
                    if(pixelAtual == 0xFF007F0E){
                        tiles[xx + (yy*WIDTH)] = new Floor_Tile(xx*16, yy*16,Tile.floorTile);
                    }
                    else if(pixelAtual == 0xFF000000){
                        tiles[xx + (yy*WIDTH)] = new Wall_Tile(xx*16,yy*16,Tile.wallTile);
                    }
                    else if(pixelAtual == 0xFF7F6A00){
                        Grass flower = new Grass(xx*16, yy*16,16,16, Game.spritesheet.getSprite(32,32,16,16));
                        Game.entities.add(flower);
                    }

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void restart(){

        Game.jogador.insertPlayer(Game.player);


        Game.entities.clear();
        Game.enemies.clear();
        Game.entities = new ArrayList<Entity>();
        Game.enemies = new ArrayList<Enemy>();
        Game.spritesheet = new Spritesheet("/spritesheet.png");
        Game.gameMode = "NORMAL";
        Game.player = new Player(0,0,16,16, Game.spritesheet.getSprite(96,128,16,16));
        Game.entities.add(Game.player);
        Game.world = new World("/mundo.png");

        Game.mundoDB.newGame();
        return;
    }

    public void render(Graphics g){
        for(int xx = 0; xx < WIDTH; xx++){
            for(int yy = 0; yy < HEIGHT; yy++){
                Tile tile = tiles[xx + (yy*WIDTH)];
                tile.render(g);
                g.drawImage(Game.spritesheet.getSprite(32,32,16,16),grassX,grassY,null );
            }
        }
    }



}
