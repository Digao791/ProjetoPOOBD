package Entidades;


import Main.Game;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Enemy extends Entity{

    public double upSPD = 2.5;
    public int type ;
    public int gravity = 1;

    public int[] maxHeight = {130, 110, 90};
    public String cor;

    public int aux = 0;
    public boolean isFalling = false;

    public Enemy(int x, int y, int width, int height, BufferedImage sprite) {
        super(x, y, width, height, sprite);

        Random rand = new Random();
        aux = rand.nextInt(3);
    }


    public void tick(){



        if(!isFalling){
            this.y -= upSPD;
                if(this.y <= maxHeight[aux]){
                    System.out.println("PosX = " + x);
                    System.out.println("PosY = " + y);
                    isFalling = true;
                }
        }
        else{
           this.y += gravity;

        }




    }


    public void render(Graphics g){
        g.drawImage(sprite,x,y,null);
    }



}
