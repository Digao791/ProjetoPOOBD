package Entidades;

import Main.Game;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Player extends Entity {

    public int ammo = 100;
    public int points = 0;
    public int id_Mundo;
    public int vida = 3;
    public int x, y;
    public boolean mouseCLK = false;
    public boolean F = false;

    public Player(int x, int y, int width, int height, BufferedImage sprite) {
        super(x, y, width, height, sprite);
    }

    public Player(int pontuacao) {
        this.points = pontuacao;
    }


    public void  tick(){

        if(vida == 0){
            Game.gameMode = "GAMEOVER";
        }
        if(F){
            for(int i = 0; i < Game.entities.size(); i++){
                Entity e = Game.entities.get(i);
                if(e instanceof Grass){
                    Game.entities.remove(e);
                    if(vida < 3){
                        vida++;
                        ammo+=10;
                        Game.ui.ammo += 10;
                    }
                    break;
                }

            }
            F = false;
        }
        enemyKill();

    }

    public void enemyKill(){
        for(int i = 0; i < Game.enemies.size(); i++){
            Enemy e = Game.enemies.get(i);
            if(mouseCLK){
                if(x >= e.getX() && x <= e.getX() + 20 && y >= e.getY() && y <= e.getY() + 20 ){
                    if(ammo >= 1) {
                        if(e.type == -1){
                            vida--;
                        }
                        Game.ui.inimigosEliminados++;
                        points++;
                        Game.enemies.remove(e);
                    }
                }
                mouseCLK = false;
            }
        }
    }




    public void render(Graphics g){
        g.drawImage(sprite,x,y,null);
    }




}
